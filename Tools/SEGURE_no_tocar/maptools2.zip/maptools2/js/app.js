// app.js — arranque, modo switching, save/load

const App = (() => {

  let currentMode = 'editor'; // 'editor' | 'pinner'
  let isDirty     = false;
  let projectLoaded = false;
  let currentFilePath = null;

  // ── Init ─────────────────────────────────────────────────
  async function init(){
    Editor.init();
    Pinner.init();
    showStartup();
  }

  // ── Startup ──────────────────────────────────────────────
  function showStartup(){
    document.getElementById('startup').style.display = 'flex';
    document.getElementById('app-shell').style.display = 'none';
  }

  function hideStartup(){
    document.getElementById('startup').style.display = 'none';
    document.getElementById('app-shell').style.display = 'flex';
  }

  function startNewProject(){
    Editor.loadData(null);
    Pinner.loadData([]);
    isDirty = false;
    currentFilePath = null;
    updateSaveDot();
    hideStartup();
    projectLoaded = true;
    setMode('editor');
    toast('Proyecto nuevo creado');
  }

  function openExistingProject(){
    document.getElementById('json-load-input').click();
  }

  function handleLoadProject(e){
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = function(ev){
      try {
        const data = JSON.parse(ev.target.result);
        if(!data.editor && !data.pinner && !data.objects) {
          toast('El archivo no contiene un proyecto válido');
          return;
        }
        loadProjectData(data);
        currentFilePath = file.name;
        hideStartup();
        projectLoaded = true;
        setMode('editor');
        isDirty = false;
        updateSaveDot();
        toast('Proyecto cargado: ' + file.name);
      } catch(err) {
        toast('Error al leer el archivo');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  }

  function loadProjectData(data){
    // Convertir formato antiguo (objects en raíz) a nuevo formato (editor.objects)
    if(data && data.objects && !data.editor){
      data = {
        editor: {
          bgColor:    data.bgColor    ?? '#1e1e1e',
          gridColor:  data.gridColor  ?? '#000000',
          refX:       data.refX       ?? 0,
          refY:       data.refY       ?? 0,
          refScale:   data.refScale   ?? 1,
          refOpacity: data.refOpacity ?? 0.5,
          objects:    data.objects    ?? [],
        },
        pinner: data.pinner || [],
      };
    }
    Editor.loadData(data.editor || null);
    Pinner.loadData(data.pinner || []);
    isDirty = false;
    updateSaveDot();
  }

  // ── Mode switching ────────────────────────────────────────
  function setMode(mode){
    currentMode = mode;

    const editorPanel = document.getElementById('editor-panel');
    const layersPanel  = document.getElementById('layers-panel');
    const pinnerPanel  = document.getElementById('pinner-panel');
    const pinnerRight  = document.getElementById('pinner-right');
    const pinCreatePanel = document.getElementById('pin-create-panel');

    const showBtn = document.getElementById('btn-show-pr');

    const editorToolbar = document.getElementById('editor-toolbar');

    if(mode === 'editor'){
      if(editorToolbar) editorToolbar.classList.remove('hidden');
      layersPanel.classList.remove('hidden');
      pinnerPanel.classList.add('hidden');
      // Ocultar panel pinner y su boton usando style.display (no clase hidden)
      pinnerRight.style.display = 'none';
      if(showBtn) showBtn.style.display = 'none';
      pinCreatePanel?.classList.add('hidden');

      document.getElementById('btn-mode-editor').classList.add('active','editor');
      document.getElementById('btn-mode-pinner').classList.remove('active','pinner');
      document.getElementById('hint').textContent = 'Click para seleccionar · Arrastrá para mover · Supr para eliminar';
      document.getElementById('coords').style.display = '';

      Pinner.deactivate();
      Editor.activate();

    } else {
      if(editorToolbar) editorToolbar.classList.add('hidden');
      layersPanel.classList.add('hidden');
      pinnerPanel.classList.add('hidden');
      // Mostrar panel pinner usando style.display (no clase hidden)
      pinnerRight.style.display = 'flex';
      if(showBtn) showBtn.style.display = 'none';

      document.getElementById('btn-mode-editor').classList.remove('active','editor');
      document.getElementById('btn-mode-pinner').classList.add('active','pinner');
      document.getElementById('hint').textContent = 'Click-derecho sobre el mapa para colocar un pin';
      document.getElementById('coords').style.display = 'none';

      Editor.deactivate();
      Pinner.activate();
    }
  }

  // ── Save / Export ─────────────────────────────────────────
  function markDirty(){
    if(!isDirty){ isDirty = true; updateSaveDot(); }
  }

  function exportProject(){
    const data = {
      editor: Editor.getData(),
      pinner: Pinner.getData(),
    };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], {type: 'application/json'});
    const a = document.createElement('a');
    a.download = 'proyecto-' + Date.now() + '.json';
    a.href = URL.createObjectURL(blob);
    a.click();
    URL.revokeObjectURL(a.href);
    isDirty = false;
    updateSaveDot('saved');
    setTimeout(()=>updateSaveDot(), 1500);
    toast('Proyecto exportado');
  }

  function updateSaveDot(state){
    const dot = document.getElementById('save-dot');
    if(!dot) return;
    dot.className = 'save-dot';
    if(state==='saved') dot.classList.add('saved');
    else if(state==='error') dot.classList.add('dirty');
    else if(isDirty) dot.classList.add('dirty');
  }

  // ── Toast ─────────────────────────────────────────────────
  function toast(msg){
    const el = document.getElementById('toast');
    if(!el) return;
    el.textContent = msg;
    el.classList.add('show');
    setTimeout(()=>el.classList.remove('show'), 2500);
  }

  // ── DOM listeners ─────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', ()=>{
    init();

    document.getElementById('btn-new-project')?.addEventListener('click', startNewProject);
    document.getElementById('btn-open-project')?.addEventListener('click', openExistingProject);
    document.getElementById('btn-mode-editor')?.addEventListener('click', ()=>setMode('editor'));
    document.getElementById('btn-mode-pinner')?.addEventListener('click', ()=>setMode('pinner'));
    document.getElementById('btn-save-now')?.addEventListener('click', exportProject);
    document.getElementById('json-load-input')?.addEventListener('change', handleLoadProject);

    document.addEventListener('keydown', e=>{
      if((e.ctrlKey||e.metaKey)&&e.key==='s'){ e.preventDefault(); exportProject(); }
    });
  });

  return { markDirty, toast, setMode, exportProject };

})();