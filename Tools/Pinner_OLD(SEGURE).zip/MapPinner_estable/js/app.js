// DOM refs
const workspace    = document.getElementById('workspace');
const mapContainer = document.getElementById('map-container');
const mapImg       = document.getElementById('map-img');
const uploadPrompt = document.getElementById('upload-prompt');
const uploadBox    = document.getElementById('upload-box');
const fileInput    = document.getElementById('file-input');
const importInput  = document.getElementById('import-input');
const pinPanel     = document.getElementById('pin-panel');
const pinModal     = document.getElementById('pin-modal');
const overlay      = document.getElementById('overlay');
const pinCountEl   = document.getElementById('pin-count');
const toastEl      = document.getElementById('toast');
const presetsPanel = document.getElementById('presets-panel');
const presetsList  = document.getElementById('presets-list');

let pendingPos = null;
let activeType = null;
let selectedId = null;

// Toast
function showToast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  setTimeout(() => toastEl.classList.remove('show'), 2200);
}

// Presets UI
loadPresets();
renderPresetsList();

let lastSavedState = null;

function captureState() {
  return {
    map: getMapDataUrl(),
    pins: JSON.stringify(getPins())
  };
}

function hasUnsavedChanges() {
  if (!lastSavedState || !getActivePresetId()) return false;
  const current = captureState();
  return current.map !== lastSavedState.map || current.pins !== lastSavedState.pins;
}

function renderPresetsList() {
  const presets = getPresets();
  const activeId = getActivePresetId();
  
  if (presets.length === 0) {
    presetsList.innerHTML = '<div class="presets-empty">Sin presets guardados.<br>Crea uno nuevo para empezar.</div>';
    return;
  }
  
  presetsList.innerHTML = presets.map((p, idx) => `
    <div class="preset-item ${p.id === activeId ? 'active' : ''}" data-id="${p.id}">
      <div class="preset-item-reorder">
        <button class="btn-reorder btn-reorder-up" data-id="${p.id}" ${idx === 0 ? 'disabled' : ''}>▲</button>
        <button class="btn-reorder btn-reorder-down" data-id="${p.id}" ${idx === presets.length - 1 ? 'disabled' : ''}>▼</button>
      </div>
      <div class="preset-item-name">${p.name}</div>
      <div class="preset-item-meta">${p.pins.length} pin${p.pins.length !== 1 ? 's' : ''}</div>
      <div class="preset-item-controls">
        <button class="preset-item-delete" data-id="${p.id}">×</button>
      </div>
    </div>
  `).join('');
  
  // Click to load preset
  presetsList.querySelectorAll('.preset-item').forEach(item => {
    item.addEventListener('click', e => {
      if (e.target.classList.contains('preset-item-delete') ||
          e.target.classList.contains('btn-reorder')) return;
      
      const targetId = item.dataset.id;
      if (targetId == getActivePresetId()) return;
      
      if (hasUnsavedChanges()) {
        const save = confirm('Tenés cambios sin guardar. ¿Querés guardar antes de cambiar de preset?');
        if (save) {
          const preset = getActivePreset();
          updatePreset(preset.id, preset.name, getMapDataUrl(), getPins());
          showToast('Cambios guardados');
        }
      }
      
      loadPresetById(targetId);
    });
  });
  
  // Delete preset
  presetsList.querySelectorAll('.preset-item-delete').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const presetId = btn.dataset.id;
      const allPresets = getPresets();
      const preset = allPresets.find(p => p.id == presetId);
      if (!preset) return;
      
      if (!confirm(`Eliminar preset "${preset.name}"?`)) return;
      
      const wasActive = presetId == getActivePresetId();
      deletePreset(presetId);
      loadPresets(); // Reload from localStorage
      
      if (wasActive) {
        // Clear screen
        clearPins();
        mapImg.style.display = 'none';
        uploadPrompt.classList.remove('hidden');
        setActivePreset(null);
        lastSavedState = null;
        updatePinCount(pinCountEl);
      }
      
      renderPresetsList();
      showToast('Preset eliminado');
    });
  });
  
  // Reorder up
  presetsList.querySelectorAll('.btn-reorder-up').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      if (movePresetUp(btn.dataset.id)) {
        renderPresetsList();
      }
    });
  });
  
  // Reorder down
  presetsList.querySelectorAll('.btn-reorder-down').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      if (movePresetDown(btn.dataset.id)) {
        renderPresetsList();
      }
    });
  });
}

function loadPresetById(id) {
  const presets = getPresets();
  const preset = presets.find(p => p.id == id);
  if (!preset) return;
  
  setActivePreset(preset.id);
  setPins(preset.pins);
  initMap(preset.map, workspace, mapContainer, mapImg, uploadPrompt, () => {
    renderPins(mapContainer, openModal);
    const t = getTransform();
    updatePinScales(mapContainer, t.scale);
    updatePinCount(pinCountEl);
    renderPresetsList();
    lastSavedState = captureState();
    showToast(`Preset "${preset.name}" cargado`);
  });
}

document.getElementById('btn-toggle-presets').addEventListener('click', () => {
  presetsPanel.classList.toggle('collapsed');
});

document.getElementById('btn-show-presets').addEventListener('click', () => {
  presetsPanel.classList.remove('collapsed');
});

document.getElementById('btn-new-preset').addEventListener('click', () => {
  const name = prompt('Nombre del nuevo preset:');
  if (!name || !name.trim()) return;
  
  if (!getMapLoaded()) {
    showToast('Cargá un mapa primero');
    return;
  }
  
  const preset = createPreset(name.trim(), getMapDataUrl(), getPins());
  setActivePreset(preset.id);
  lastSavedState = captureState();
  renderPresetsList();
  showToast(`Preset "${preset.name}" creado`);
});

document.getElementById('btn-save-preset').addEventListener('click', () => {
  const activeId = getActivePresetId();
  
  if (!activeId) {
    showToast('Seleccioná un preset primero o creá uno nuevo');
    return;
  }
  
  if (!getMapLoaded()) {
    showToast('Cargá un mapa primero');
    return;
  }
  
  const preset = getActivePreset();
  const name = prompt('Nombre del preset:', preset.name);
  if (!name || !name.trim()) return;
  
  updatePreset(activeId, name.trim(), getMapDataUrl(), getPins());
  lastSavedState = captureState();
  renderPresetsList();
  showToast(`Preset "${name}" guardado`);
});

// Build type grid from PIN_TYPES
const typeGrid = document.getElementById('type-grid');
Object.entries(PIN_TYPES).forEach(([key, def]) => {
  const btn = document.createElement('div');
  btn.className = 'type-btn';
  btn.dataset.type = key;
  btn.innerHTML = `<span class="type-icon">${def.icon}</span><span class="type-label">${def.label}</span>`;
  btn.style.setProperty('--type-color', def.color);
  btn.addEventListener('click', () => {
    activeType = key;
    document.querySelectorAll('.type-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });
  typeGrid.appendChild(btn);
});

// Map init callback
function onMapLoaded() {
  const loaded = loadPins();
  setPins(loaded);
  renderPins(mapContainer, openModal);
  const t = getTransform();
  updatePinScales(mapContainer, t.scale);
  updatePinCount(pinCountEl);
}

// Upload
uploadBox.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', e => {
  const f = e.target.files[0];
  if (f) loadImageFile(f, workspace, mapContainer, mapImg, uploadPrompt, onMapLoaded);
});
uploadBox.addEventListener('dragover', e => e.preventDefault());
uploadBox.addEventListener('drop', e => {
  e.preventDefault();
  const f = e.dataTransfer.files[0];
  if (f && f.type.startsWith('image/')) loadImageFile(f, workspace, mapContainer, mapImg, uploadPrompt, onMapLoaded);
});

document.getElementById('btn-change-map').addEventListener('click', () => fileInput.click());

// Clear
document.getElementById('btn-clear').addEventListener('click', () => {
  if (!confirm('Eliminar todos los pins del mapa?')) return;
  clearPins();
  savePins(getPins());
  renderPins(mapContainer, openModal);
  const t = getTransform();
  updatePinScales(mapContainer, t.scale);
  updatePinCount(pinCountEl);
  showToast('Pins eliminados');
});

// Export
document.getElementById('btn-export').addEventListener('click', () => {
  if (!getMapLoaded()) { showToast('Cargá un mapa primero'); return; }
  exportSave(getPins(), getMapDataUrl());
  showToast('Exportado correctamente');
});

// Import
document.getElementById('btn-import').addEventListener('click', () => importInput.click());
importInput.addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) return;
  importSave(file, data => {
    if (!confirm(`Importar ${data.pins.length} pin(s)? Esto reemplaza el mapa y pins actuales.`)) return;
    saveMap(data.map);
    setPins(data.pins);
    savePins(getPins());
    initMap(data.map, workspace, mapContainer, mapImg, uploadPrompt, () => {
      renderPins(mapContainer, openModal);
      const t = getTransform();
      updatePinScales(mapContainer, t.scale);
      updatePinCount(pinCountEl);
      showToast(`${getPins().length} pin(s) importados`);
    });
  });
  importInput.value = '';
});

// Right-click → open panel directly
workspace.addEventListener('contextmenu', e => {
  e.preventDefault();
  if (!getMapLoaded()) return;
  pendingPos = getMapCoords(e.clientX, e.clientY, workspace);
  openPanel();
});

function openPanel(preselect) {
  activeType = preselect || null;
  document.querySelectorAll('.type-btn').forEach(b => {
    b.classList.remove('active');
    if (b.dataset.type === activeType) b.classList.add('active');
  });
  document.getElementById('pin-title').value = '';
  document.getElementById('pin-desc').value  = '';
  overlay.classList.add('visible');
  pinPanel.classList.add('visible');
  setTimeout(() => document.getElementById('pin-title').focus(), 80);
}

function closePanel() {
  pinPanel.classList.remove('visible');
  overlay.classList.remove('visible');
  pendingPos = null;
  activeType = null;
}

document.getElementById('panel-close').addEventListener('click', closePanel);
document.getElementById('btn-cancel').addEventListener('click', closePanel);
overlay.addEventListener('click', closePanel);

document.getElementById('btn-confirm').addEventListener('click', () => {
  if (!pendingPos) return;
  if (!activeType) { showToast('Seleccioná una categoría'); return; }
  const def = PIN_TYPES[activeType];
  const pin = {
    id:    Date.now() + Math.random(),
    type:  activeType,
    x:     pendingPos.x,
    y:     pendingPos.y,
    title: document.getElementById('pin-title').value.trim() || def.label,
    desc:  document.getElementById('pin-desc').value.trim()
  };
  addPin(pin);
  savePins(getPins());
  createPinEl(pin, mapContainer, openModal);
  const t = getTransform();
  updatePinScales(mapContainer, t.scale);
  updatePinCount(pinCountEl);
  closePanel();
  showToast('Pin guardado');
});

document.getElementById('pin-title').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('btn-confirm').click();
});

// Read modal
function openModal(id) {
  const pin = findPin(id);
  if (!pin) return;
  const def = PIN_TYPES[pin.type] || { label: pin.type, color: '#888', icon: '?' };
  selectedId = id;
  document.getElementById('modal-stripe').style.background = def.color;
  document.getElementById('modal-stripe').className = 'modal-stripe';
  document.getElementById('modal-pin-icon').textContent = def.icon;
  document.getElementById('modal-pin-icon').style.color = def.color;
  document.getElementById('modal-tag').textContent  = def.label;
  document.getElementById('modal-tag').style.background = def.color + '22';
  document.getElementById('modal-tag').style.color = def.color;
  document.getElementById('modal-title').textContent = pin.title || '(sin nombre)';
  document.getElementById('modal-desc').textContent  = pin.desc  || 'Sin descripción.';
  
  const hideBtn = document.getElementById('btn-hide');
  hideBtn.textContent = pin.hidden ? 'Unhide' : 'Hide';
  hideBtn.classList.toggle('active', pin.hidden);
  
  pinModal.classList.add('visible');
}

document.getElementById('btn-close-modal').addEventListener('click', () => {
  pinModal.classList.remove('visible'); selectedId = null;
});

document.getElementById('btn-hide').addEventListener('click', () => {
  if (!selectedId) return;
  const pin = findPin(selectedId);
  if (!pin) return;
  pin.hidden = !pin.hidden;
  savePins(getPins());
  renderPins(mapContainer, openModal);
  const t = getTransform();
  updatePinScales(mapContainer, t.scale);
  const hideBtn = document.getElementById('btn-hide');
  hideBtn.textContent = pin.hidden ? 'Unhide' : 'Hide';
  hideBtn.classList.toggle('active', pin.hidden);
});

document.getElementById('btn-del').addEventListener('click', () => {
  if (!selectedId) return;
  removePin(selectedId);
  savePins(getPins());
  renderPins(mapContainer, openModal);
  const t = getTransform();
  updatePinScales(mapContainer, t.scale);
  updatePinCount(pinCountEl);
  pinModal.classList.remove('visible');
  selectedId = null;
  showToast('Pin eliminado');
});

pinModal.addEventListener('click', e => {
  if (e.target === pinModal) { pinModal.classList.remove('visible'); selectedId = null; }
});

// Panning
setupPanning(workspace, mapContainer, mapImg);

// Auto-load
const savedMap = loadMap();
if (savedMap) initMap(savedMap, workspace, mapContainer, mapImg, uploadPrompt, onMapLoaded);
