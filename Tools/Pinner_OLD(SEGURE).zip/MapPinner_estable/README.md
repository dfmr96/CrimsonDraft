# MapPinner

Herramienta para crear mapas interactivos con pins.

## Estructura

```
MapPinner/
├── index.html        → punto de entrada, abrir en navegador
├── css/
│   └── style.css     → todos los estilos
├── js/
│   ├── storage.js    → localStorage, exportar e importar JSON
│   ├── pins.js       → lógica y renderizado de pins
│   ├── map.js        → carga de imagen, pan, zoom
│   └── app.js        → coordinación general y eventos UI
├── saves/            → guardar acá los .json exportados
└── README.md
```

## Uso

1. Abrir `index.html` en el navegador (doble click o arrastrar a Chrome/Firefox)
2. Cargar una imagen de mapa
3. Click derecho sobre el mapa para crear un pin
4. Click izquierdo sobre un pin para ver su información
5. Usar "Exportar .json" para compartir el mapa con pins
6. Usar "Importar .json" para cargar un guardado compartido

## Nota

El archivo se abre directamente en el navegador, sin necesidad de servidor.
Los pins se guardan automáticamente en el navegador (localStorage).
Para compartir con otra persona, exportar el .json y pasarle ese archivo junto con el index.html.
